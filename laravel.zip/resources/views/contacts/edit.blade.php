<?php ?>
@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <h1>Edit {{ $contact->name }}</h1>

            <!-- if there are creation errors, they will show here -->
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            {{ Form::model($contact, array('route' => array('contacts.update', $contact->id), 'method' => 'PUT','novalidate'=>'novalidate')

            ) }}

            <div class="form-group">
                {{ Form::label('name', 'Name') }}
                {{ Form::text('name', null, array('class' => 'form-control')) }}
            </div>

            <div class="form-group">
                {{ Form::label('email', 'Email') }}
                {{ Form::email('email', null, array('class' => 'form-control')) }}
            </div>
            <div class="form-group">
                {{ Form::label('mobile', 'Mobile') }}
                {{ Form::text('mobile', null, array('class' => 'form-control')) }}
            </div>
            <div class="form-group">
                {{ Form::label('country', 'Country') }}
                {{ Form::text('country', null, array('class' => 'form-control')) }}
            </div>
            <div class="form-group">
                {{ Form::label('city', 'City') }}
                {{ Form::text('city', null, array('class' => 'form-control')) }}
            </div>
            <div class="form-group">
                {{ Form::label('street', 'Street') }}
                {{ Form::text('street', null, array('class' => 'form-control')) }}
            </div>
            {{ Form::submit('Edit the contact!', array('class' => 'btn btn-primary')) }}

            {{ Form::close() }}
        </div>
    </div>
@endsection