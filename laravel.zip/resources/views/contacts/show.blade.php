@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <h2>My contacts</h2>
            <a href="add" class="btn btn-primary">Add</a>

            <table class="table table-striped">
                <thead>
                <tr>
                    <th>name</th>
                    <th>email</th>
                    <th>mobile</th>
                    <th>Country</th>
                    <th>City</th>
                    <th>street</th>
                    <th>update/remove</th>
                </tr>
                </thead>
                <tbody>


                    <tr>
                        <td>{{ $contact->name }}</td>
                        <td>{{ $contact->email }}</td>
                        <td>{{ $contact->mobile }}</td>
                        <td>{{ $contact->country }}</td>
                        <td>{{ $contact->city }}</td>
                        <td>{{ $contact->street }}</td>
                        <!-- adding update and delete -->
                        <td>
                            <!-- show the contacts (uses the show method found at GET /nerds/{id} -->
                            <a class="btn btn-small btn-success" href="{{ URL::to('contacts/' . $contact->id) }}">Show this contact</a>

                            <!-- edit this nerd (uses the edit method found at GET /nerds/{id}/edit -->
                            <a class="btn btn-small btn-info" href="{{ URL::to('contacts/' . $contact->id . '/edit') }}">Edit this contact</a>

                        </td>

                    </tr>


                </tbody>
            </table>
        </div>
    </div>
@endsection
