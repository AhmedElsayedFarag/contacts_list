@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="">
                <h1 class="text-center">Add Contacts</h1>
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
                <form class="form-horizontal" role="form" action="contacts" method="post" novalidate>
                    {{ csrf_field() }}
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="name">Name :</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="name" placeholder="Enter  Name" name="name"
                                   value="{{old('name')}}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="email">Email:</label>
                        <div class="col-sm-10">
                            <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" value="{{old('email')}}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="mobile">Mobile:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="mobile" placeholder="Enter Mobile" name="mobile" value="{{old('mobile')}}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="country">country:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control"  id="country" name="country" placeholder="Enter country" value="{{old('country')}}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="city">City:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control"  id="city" name="city" placeholder="Enter city" value="{{old('city')}}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="street">Street:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control"  id="street" name="street" placeholder="Enter street" value="{{old('street')}}">
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" class="btn btn-primary" value="add">
                            <input type="reset" class="btn btn-danger">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection