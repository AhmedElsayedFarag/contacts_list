<?php

namespace Laravel\Http\Controllers;
use Laravel\User;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;

class UserController extends Controller
{
	public function __construct() {
//		if(empty(Auth::user()->id)){return Redirect::to('login');}

		$this->middleware('auth');
	}
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
//	    if(empty(Auth::user()->id)){return Redirect::to('login');}

	    // get the contact
	    $user = User::find($id);

	    // show the edit form and pass the nerd
	    return view('users.edit',compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
//	    if(empty(Auth::user()->id)){return Redirect::to('login');}

	    // validate
	    $this->validate($request, [
		    'name' => 'required',
		    'email' => 'required|email|unique:users,id,'.$id
	    ]);


	    // process the update(store in data base)
	    // store
	    $user = User::find($id);
	    $user->name          = Input::get('name');
	    $user->email         = Input::get('email');
	    $user->save();

	    // redirect
	    return \Redirect::to('home');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
