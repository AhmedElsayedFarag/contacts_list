<?php

namespace Laravel\Http\Controllers;

use Laravel\Contact;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

class ContactController extends Controller
{
	public function __construct() {
//		if(empty(Auth::user()->id)){return Redirect::to('login');}

		$this->middleware('auth');
	}
	public function add() {
		if(empty(Auth::user()->id)){return Redirect::to('login');}

		return view('contacts/addcontacts');
	}
	/**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
    	//check if not logged in
    	if(empty(Auth::user()->id)){return Redirect::to('login');}
	    // get all the contacts
	    //$contacts = Contact::all();
	    $contacts = Contact::orderBy('id','ASC')->get()
	                                            ->where('user_id','=',Auth::user()->id);

	    // load the view and pass the contacts
	    return view('contacts.index')->with('contacts', $contacts);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
	    if(empty(Auth::user()->id)){return Redirect::to('login');}

	    // load the create form (app/views/contacts/create.blade.php)
	    return view('contacts.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
	    if(empty(Auth::user()->id)){return Redirect::to('login');}

	    // validate
	    $this->validate($request, [
		    'name' => 'required',
		    'email' => 'required|email|unique:contacts',
		    'mobile' => 'required|Digits:11|unique:contacts',
		    'country' => 'required',
		    'city' => 'required',
		    'street' => 'required'
	    ]);


		    // store
		    $contact = new Contact;
	        $contact->name       = Input::get('name');
	        $contact->email      = Input::get('email');
	        $contact->mobile     = Input::get('mobile');
	        $contact->country    = Input::get('country');
	        $contact->city       = Input::get('city');
	        $contact->street     = Input::get('street');
	        $contact->user_id    = Auth::user()->id;
	        $contact->save();

		    // redirect
		    //Session::flash('message', 'Successfully created!');
	        return \Redirect::to('contacts');

    }

    /**
     * Display the specified resource.
     *
     * @param  \Laravel\Contact  $contact
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
	    if(empty(Auth::user()->id)){return Redirect::to('login');}

	    // get the contact
	    $contact = Contact::find($id);

	    // show the view and pass the contact to it
	    return view('contacts.show')
	               ->with('contact', $contact);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \Laravel\Contact  $contact
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
	    // get the contact
	    $contact = Contact::find($id);

	    // show the edit form and pass the contact
	    return view('contacts.edit',compact('contact'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Laravel\Contact  $contact
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
//	    if(empty(Auth::user()->id)){return Redirect::to('login');}

	    // validate
	    $this->validate($request, [
		    'name' => 'required',
		    'email' => 'required|email|unique:contacts',
		    'mobile' => 'required|Digits:11|unique:contacts',
		    'country' => 'required',
		    'city' => 'required',
		    'street' => 'required'
	    ]);


	    // process the update(store in data base)
		    // store
	    $contact = Contact::find($id);
	    $contact->name       = Input::get('name');
	    $contact->email      = Input::get('email');
	    $contact->mobile     = Input::get('mobile');
	    $contact->country    = Input::get('country');
	    $contact->city       = Input::get('city');
	    $contact->street     = Input::get('street');
	    $contact->user_id    = Auth::user()->id;
	    $contact->save();

		    // redirect
	        return \Redirect::to('contacts');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \Laravel\Contact  $contact
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
	    if(empty(Auth::user()->id)){return Redirect::to('login');}

	    // delete
	    $contact = Contact::find($id);
	    $contact->delete();

	    // redirect
	    return \Redirect::to('contacts');
    }
}
