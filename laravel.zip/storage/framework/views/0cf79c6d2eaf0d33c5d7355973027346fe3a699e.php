<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="">
                <h1 class="text-center">Add Contacts</h1>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form class="form-horizontal" role="form" action="contacts" method="post" novalidate>
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="name">Name :</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="name" placeholder="Enter  Name" name="name"
                                   value="<?php echo e(old('name')); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="email">Email:</label>
                        <div class="col-sm-10">
                            <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" value="<?php echo e(old('email')); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="mobile">Mobile:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="mobile" placeholder="Enter Mobile" name="mobile" value="<?php echo e(old('mobile')); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="country">country:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control"  id="country" name="country" placeholder="Enter country" value="<?php echo e(old('country')); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="city">City:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control"  id="city" name="city" placeholder="Enter city" value="<?php echo e(old('city')); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="street">Street:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control"  id="street" name="street" placeholder="Enter street" value="<?php echo e(old('street')); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" class="btn btn-primary" value="add">
                            <input type="reset" class="btn btn-danger">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>