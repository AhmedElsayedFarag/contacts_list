<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <h2>My contacts</h2>
            <a href="add" class="btn btn-primary">Add</a>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>name</th>
                    <th>email</th>
                    <th>mobile</th>
                    <th>Country</th>
                    <th>City</th>
                    <th>street</th>
                    <th>update/remove</th>
                </tr>
                </thead>
                <tbody>

                <tr>
                    <td>ahmed elsayed</td>
                    <td>ahmed elsayed</td>
                    <td>ahmed elsayed</td>
                    <td>ahmed elsayed</td>
                    <td>ahmed elsayed</td>
                    <td>ahmed elsayed</td>
                    <td><a href="" class="btn btn-primary">update</a> <a href="" class="btn btn-danger">remove</a></td>
                </tr>

                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>