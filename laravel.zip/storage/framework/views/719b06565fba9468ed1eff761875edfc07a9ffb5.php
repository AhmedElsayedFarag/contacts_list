<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <h2>My contacts</h2>
            <a href="add" class="btn btn-primary">Add</a>

            <table class="table table-striped">
                <thead>
                <tr>
                    <th>name</th>
                    <th>email</th>
                    <th>mobile</th>
                    <th>Country</th>
                    <th>City</th>
                    <th>street</th>
                    <th>update/remove</th>
                </tr>
                </thead>
                <tbody>


                    <tr>
                        <td><?php echo e($contact->name); ?></td>
                        <td><?php echo e($contact->email); ?></td>
                        <td><?php echo e($contact->mobile); ?></td>
                        <td><?php echo e($contact->country); ?></td>
                        <td><?php echo e($contact->city); ?></td>
                        <td><?php echo e($contact->street); ?></td>
                        <!-- adding update and delete -->
                        <td>
                            <!-- show the contacts (uses the show method found at GET /nerds/{id} -->
                            <a class="btn btn-small btn-success" href="<?php echo e(URL::to('contacts/' . $contact->id)); ?>">Show this contact</a>

                            <!-- edit this nerd (uses the edit method found at GET /nerds/{id}/edit -->
                            <a class="btn btn-small btn-info" href="<?php echo e(URL::to('contacts/' . $contact->id . '/edit')); ?>">Edit this contact</a>

                        </td>

                    </tr>


                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>