<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <h2>My contacts</h2>
            <a href="add" class="btn btn-primary">Add</a>
            <!-- will be used to show any messages if there is no contacts -->
            <?php if(count($contacts) == 0): ?>
                <div class="alert alert-info" style="margin-top: 10px"><strong>There is no contacts</strong></div>
                <?php else: ?>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>name</th>
                        <th>email</th>
                        <th>mobile</th>
                        <th>Country</th>
                        <th>City</th>
                        <th>street</th>
                        <th>update/remove</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($value->name); ?></td>
                            <td><?php echo e($value->email); ?></td>
                            <td><?php echo e($value->mobile); ?></td>
                            <td><?php echo e($value->country); ?></td>
                            <td><?php echo e($value->city); ?></td>
                            <td><?php echo e($value->street); ?></td>
                            <!-- adding update and delete -->
                            <td>
                                <!-- delete the nerd (uses the destroy method DESTROY /nerds/{id} -->
                                <!-- we will add this later since its a little more complicated than the other two buttons -->
                            <?php echo e(Form::open(array('url' => 'contacts/' . $value->id, 'class' => 'pull-right'))); ?>

                            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                            <?php echo e(Form::submit('Delete', array('class' => 'btn btn-danger'))); ?>

                            <?php echo e(Form::close()); ?>

                            <!-- show the contacts (uses the show method found at GET /nerds/{id} -->
                                <a class="btn btn-small btn-success" href="<?php echo e(URL::to('contacts/' . $value->id)); ?>">Show</a>

                                <!-- edit this nerd (uses the edit method found at GET /nerds/{id}/edit -->
                                <a class="btn btn-small btn-info" href="<?php echo e(URL::to('contacts/' . $value->id . '/edit')); ?>">Edit</a>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>