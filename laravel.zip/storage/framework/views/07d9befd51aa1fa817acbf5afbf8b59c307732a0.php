<?php ?>


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <h1>Edit <?php echo e($contact->name); ?></h1>

            <!-- if there are creation errors, they will show here -->
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php echo e(Form::model($contact, array('route' => array('contacts.update', $contact->id), 'method' => 'PUT','novalidate'=>'novalidate')

            )); ?>


            <div class="form-group">
                <?php echo e(Form::label('name', 'Name')); ?>

                <?php echo e(Form::text('name', null, array('class' => 'form-control'))); ?>

            </div>

            <div class="form-group">
                <?php echo e(Form::label('email', 'Email')); ?>

                <?php echo e(Form::email('email', null, array('class' => 'form-control'))); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('mobile', 'Mobile')); ?>

                <?php echo e(Form::text('mobile', null, array('class' => 'form-control'))); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('country', 'Country')); ?>

                <?php echo e(Form::text('country', null, array('class' => 'form-control'))); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('city', 'City')); ?>

                <?php echo e(Form::text('city', null, array('class' => 'form-control'))); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('street', 'Street')); ?>

                <?php echo e(Form::text('street', null, array('class' => 'form-control'))); ?>

            </div>
            <?php echo e(Form::submit('Edit the contact!', array('class' => 'btn btn-primary'))); ?>


            <?php echo e(Form::close()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>